﻿using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using MGI;
using MGI.GameState;
using MGI.Types;
using MGI.UI.MachUI;
using System.Collections.Generic;

namespace KopachrisNH5CheatsMod
{
    [BepInPlugin("nh5.kopachris.cheatsmod", "NASCAR Heat 5 Cheats mod", "1.0.0.0")]
    [BepInProcess("NASCARHeat5.exe")]
    public class Plugin : BaseUnityPlugin
    {
        internal static ManualLogSource Log;
        private void Awake()
        {
            // Plugin startup logic
            Log = base.Logger;
            Log.LogInfo($"Plugin '{PluginInfo.PLUGIN_NAME}' ({PluginInfo.PLUGIN_GUID}) is loaded! NASCAR Heat 5 version: {MGI.Version.GetBuildDateTime()}");

            var harmony = new Harmony(PluginInfo.PLUGIN_GUID);
            harmony.PatchAll();
        }
    }

    [HarmonyPatch(typeof(MGI.UI.Screens.Common_CharacterCreator.Common_CharacterCreatorHandler), "store_name")]
    static class Kopachris_NH5_Cheats_Patch
    {
        static bool check_and_run_cheats(string raw_cheat_string)
        {
            Plugin.Log.LogDebug($"In Kopachris_NH5_Cheats_Patch.check_and_run_cheats with raw_cheat_string='{raw_cheat_string}'.");
            if (raw_cheat_string == null) return false;

            string cheat_string = raw_cheat_string.Trim().ToLower();

            ICareerProgress cp = GSProxy.gameState.GetCareerProgress();
            if (cp == null)
            {
                Plugin.Log.LogWarning("No ICareerProgress from GetCareerProgress().");
                return false;
            }

            ICareerPlayerState cps = cp.GetCareerPlayerState();
            if (cps == null)
            {
                Plugin.Log.LogWarning("No ICareerPlayerState from GetCareerPlayerState().");
                return false;
            }

            ICareerPlayerStateController cpsc = (ICareerPlayerStateController)cps;
            if (cpsc == null)
            {
                Plugin.Log.LogWarning("No ICareerPlayerStateController from ICareerPlayerState.");
                return false;
            }

            bool did_cheat = false;

            // Add money cheats
            if (cheat_string.Contains("rosebud"))
            {
                // Add $100,000
                cpsc.AddMoney(100000);
                did_cheat = true;
                Plugin.Log.LogInfo($"Ran cheat 'rosebud' from {raw_cheat_string}.");
            }
            else if (cheat_string.Contains("sugardaddy"))
            {
                // Add $1,000,000
                cpsc.AddMoney(1000000);
                did_cheat = true;
                Plugin.Log.LogInfo($"Ran cheat 'sugardaddy' from {raw_cheat_string}.");
            }

            // Remove money cheats
            if (cheat_string.Contains("loanshark"))
            {
                // Remove $100,000
                cpsc.RemoveMoney(100000);
                did_cheat = true;
                Plugin.Log.LogInfo($"Ran cheat 'loanshark' from {raw_cheat_string}.");
            }
            else if (cheat_string.Contains("bigdebt"))
            {
                // Remove $1,000,000
                cpsc.RemoveMoney(1000000);
                did_cheat = true;
                Plugin.Log.LogInfo($"Ran cheat 'bigdebt' from {raw_cheat_string}.");
            }
            else if (cheat_string.Contains("donaldtrump"))
            {
                // Remove all the player's money
                int money = cps.GetMoney();
                cpsc.RemoveMoney(money);
                did_cheat = true;
                Plugin.Log.LogInfo($"Ran cheat 'donaldtrump' from {raw_cheat_string}.");
            }

            // Rivals and fans cheats
            if (cheat_string.Contains("jekyll"))
            {
                // Make all drivers friends
                // TODO
            }
            else if (cheat_string.Contains("hyde"))
            {
                // Make all drivers rivals
                // TODO
            }
            else if (cheat_string.Contains("swiss"))
            {
                // Make all drivers neutral
                // TODO
            }

            if (cheat_string == "johnwardley")
            {
                // Add 10,000 fans. Wow!
                cpsc.AddFans(10000);
                did_cheat = true;
                Plugin.Log.LogInfo($"Ran cheat 'johnwardley' from {raw_cheat_string}.");
            }

            return did_cheat;
        }
        static void Prefix(ref Dictionary<string, string> __state)
        {
            // if (!Main.enabled) return;
            Plugin.Log.LogDebug("In Kopachris_NH5_Cheats_Patch.Prefix.");

            ICareerProgress cp = GSProxy.gameState.GetCareerProgress();
            if (cp == null)
            {
                Plugin.Log.LogWarning("No ICareerProgress from GetCareerProgress().");
                return;
            }

            ICareerPlayerState cps = cp.GetCareerPlayerState();
            if (cps == null)
            {
                Plugin.Log.LogWarning("No ICareerPlayerState from GetCareerPlayerState().");
                return;
            }

            ICareerPlayerStateController cpsc = (ICareerPlayerStateController)cps;
            if (cpsc == null)
            {
                Plugin.Log.LogWarning("No ICareerPlayerStateController from ICareerPlayerState.");
                return;
            }

            __state = new Dictionary<string, string>();
            __state["orig_first_name"] = cpsc.GetCharacterFirstName();
            __state["orig_last_name"] = cpsc.GetCharacterLastName();
        }

        static void Postfix(ref MGI.UI.Screens.Common_CharacterCreator.Common_CharacterCreatorHandler __instance, Dictionary<string, string> __state)
        {
            // if (!Main.enabled) return;
            Plugin.Log.LogDebug($"In Kopachris_NH5_Cheats_Patch.Postfix with orig_first_name='{__state["orig_first_name"]}' and orig_last_name='{__state["orig_last_name"]}'.");

            ICareerProgress cp = GSProxy.gameState.GetCareerProgress();
            if (cp == null)
            {
                Plugin.Log.LogWarning("No ICareerProgress from GetCareerProgress().");
                return;
            }

            ICareerPlayerState cps = cp.GetCareerPlayerState();
            if (cps == null)
            {
                Plugin.Log.LogWarning("No ICareerPlayerState from GetCareerPlayerState().");
                return;
            }

            ICareerPlayerStateController cpsc = (ICareerPlayerStateController)cps;
            if (cpsc == null)
            {
                Plugin.Log.LogWarning("No ICareerPlayerStateController from ICareerPlayerState.");
                return;
            }

            IMachScreenHandler screen = (IMachScreenHandler)__instance;
            if (screen == null)
            {
                Plugin.Log.LogWarning("No IMachScreenHandler from __instance.");
                return;
            }

            string new_first_name = screen.GetScreen().GetValue<string, string>("GetNameById", "FirstName");
            string new_last_name = screen.GetScreen().GetValue<string, string>("GetNameById", "LastName");

            string new_name = new_first_name + new_last_name;

            bool did_cheat = check_and_run_cheats(new_name);
            if (did_cheat)
            {
                Plugin.Log.LogInfo("Ran cheat, so attempting to change name back to what it was...");
                // This doesn't work for some reason... 🤔
                cp.SetCharacterName(__state["orig_first_name"], __state["orig_last_name"]);
                if (BaseMonoSingleton<CustomDriverNameBuilder, CustomDriverNameBuilder>.isInstantiated) 
                {
                    BaseMonoSingleton<CustomDriverNameBuilder, CustomDriverNameBuilder>.Instance.MaybeUpdateDriverName();
                }
            }
            else
            {
                Plugin.Log.LogInfo("Did not run cheat, name change allowed.");
            }
        }
    }
}
